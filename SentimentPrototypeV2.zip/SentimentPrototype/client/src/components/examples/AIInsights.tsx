import AIInsights from '../AIInsights';

export default function AIInsightsExample() {
  return (
    <div className="p-8">
      <AIInsights />
    </div>
  );
}
