import ChannelsIntegrated from '../ChannelsIntegrated';

export default function ChannelsIntegratedExample() {
  return (
    <div className="p-8">
      <ChannelsIntegrated />
    </div>
  );
}
