import FeedbackHighlights from '../FeedbackHighlights';

export default function FeedbackHighlightsExample() {
  return (
    <div className="p-8">
      <FeedbackHighlights />
    </div>
  );
}
