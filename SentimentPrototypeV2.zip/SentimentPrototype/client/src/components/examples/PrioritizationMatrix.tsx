import PrioritizationMatrix from '../PrioritizationMatrix';

export default function PrioritizationMatrixExample() {
  return (
    <div className="p-8">
      <PrioritizationMatrix />
    </div>
  );
}
