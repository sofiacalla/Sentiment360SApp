import PriorityList from '../PriorityList';

export default function PriorityListExample() {
  return (
    <div className="p-8">
      <PriorityList />
    </div>
  );
}
