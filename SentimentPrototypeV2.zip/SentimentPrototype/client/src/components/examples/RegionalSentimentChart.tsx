import RegionalSentimentChart from '../RegionalSentimentChart';

export default function RegionalSentimentChartExample() {
  return (
    <div className="p-8">
      <RegionalSentimentChart />
    </div>
  );
}
