import SentimentTrendChart from '../SentimentTrendChart';

export default function SentimentTrendChartExample() {
  return (
    <div className="p-8">
      <SentimentTrendChart />
    </div>
  );
}
