import UsageMetricsChart from '../UsageMetricsChart';

export default function UsageMetricsChartExample() {
  return (
    <div className="p-8">
      <UsageMetricsChart />
    </div>
  );
}
